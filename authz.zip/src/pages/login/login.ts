import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import * as firebase from 'firebase';
import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';

import { UserserviceProvider } from '../../providers/userservice/userservice';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
  providers: [UserserviceProvider]
})
export class LoginPage {

public email: string;
public password: string;
public fireAuth:any;
public name: any;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams, 
    public loadingCtrl: LoadingController,
    public tostCtrl: ToastController,
    private userService: UserserviceProvider
  ) {
    this.fireAuth = firebase.auth();
  }

  ionViewDidLoad() {
    console.log('LoginPage');
  }
  submitLogin(){
    var that = this;
    var loader = this.loadingCtrl.create({
      content: "Please wait..."
    })
    loader.present();

    this.userService.loginUserService(this.email,this.password).then(authData => {
      //successful
      loader.dismiss();
      that.navCtrl.setRoot(HomePage);
    }, error =>{
      loader.dismiss();
      //Unable to log in
      let toast = this.tostCtrl.create({
        message: error,
        duration: 3000,
        position: "top"
      });
      toast.present();
      that.password ="";//empty the password field
    }
    );

  }
  forgotPassword(){
    this.fireAuth.signInWithPopup(new firebase.auth.GoogleAuthProvider()).then(res =>{
      console.log(res);
    }).catch(error =>{
      console.log(error.message);
    })
  }

  loginWithGoogle(){

  }

  redirectToSignup(){
    this.navCtrl.push(SignupPage);
  }

}
