import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController } from 'ionic-angular';
import * as firebase from 'firebase';

import { UserserviceProvider } from '../../providers/userservice/userservice';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
  providers: [UserserviceProvider]
})
export class SignupPage {

  public skills: string;
  public email: string;
  public phone: any;
  public password: string;
  public first_name: string;
  public last_name: string;
  public city: string;
  public state: any;
  public country: any;
  public isJobSeeker: boolean;


  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public toastCtrl: ToastController,
    public loadingCtrl: LoadingController,
    public userserviceProvider: UserserviceProvider
  ) {
     
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }

  doSignup(){
     var account = {
       first_name: this.first_name,
       last_name: this.last_name || '',
       skills: this.skills || '',
       email: this.email,
       phone: this.phone || '',
       password: this.password,
       city: this.city || '',
       state: this.state || '',
       country: this.country || '',
       isJobSeeker: this.isJobSeeker || '',
     };
     var that = this;
     
     var loader = this.loadingCtrl.create({
       content: 'Please wait...',
     });
     loader.present();

     this.userserviceProvider.signupUserService(account).then(authData =>{
       //successful
       loader.dismiss();
       that.navCtrl.setRoot(HomePage);
     },error =>{
       loader.dismiss();
       //unable to login
       let toast =this.toastCtrl.create({
         message: error,
         duration: 3000,
         position: 'top'
       });
       toast.present();
       that.password = ""//empty the password field
     });
  }
}
