import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { HomePage } from '../home/home';
import { Geolocation } from '@ionic-native/geolocation';
import { WeatherProvider } from '../../providers/weather/weather';

@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {
city: string;
state: string;
// cords:{
//   lat: string,
//   long:string
// }
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams, 
    private weatherProvider: WeatherProvider,
    private storage: Storage,
    private geolocation: Geolocation
  ) {
   this.storage.get('location').then((val)  =>{
    if(val !=null){
      let location = JSON.parse(val);
      this.city = location.city;
      this.state = location.state;
    }else{
      this.city = 'Lahore';
      this.state ='Pakistan';
    }
   })
    
  }

  

  getMyLocation(city, state){

    
    
    this.geolocation.getCurrentPosition().then((resp) => {
       var cords = {
         lat : resp.coords.latitude,
         long : resp.coords.longitude
      }
       

      this.weatherProvider.getLatLong(cords.lat, cords.long).subscribe( weather => {
        //this.city = weather.current_observation.observation_location.city.slice(0, -5);
        this.city = weather.current_observation.display_location.city;
        this.state = weather.current_observation.observation_location.country;
      console.log(weather)
      console.log("lat: "+cords.lat, cords.long);
      })

     }).catch((error) => {
       console.log('Error getting location', error);
       
     });
  }
  

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingsPage');
  }
saveForm(){
  let location = {
    city: this.city,
    state: this.state
  }
  this.storage.set('location',JSON.stringify(location));
  this.navCtrl.push(HomePage);
  //console.log(location.city);  
}
}
