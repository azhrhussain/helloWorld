import { ActivatedRoute } from '@angular/router';
import { CategoryService } from './../category.service';
import { ProductService } from './../product.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  product$;
  categories$;
  category: string;
  constructor(private productService: ProductService, private categoryService: CategoryService, route: ActivatedRoute) { 
    this.product$ = this.productService.getAll();
    this.categories$ = this.categoryService.getAll();
    
    route.queryParamMap.subscribe(parms =>{
      this.category = parms.get('category');
    });
  }

  ngOnInit() {
  }

}
