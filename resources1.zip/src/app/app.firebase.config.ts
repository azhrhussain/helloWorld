export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyD04PQA2BGxNfbg7FbexReWWZip3hDyKdU",
    authDomain: "suzuki-fa60a.firebaseapp.com",
    databaseURL: "https://suzuki-fa60a.firebaseio.com",
    projectId: "suzuki-fa60a",
    storageBucket: "suzuki-fa60a.appspot.com",
    messagingSenderId: "851069929889"
}