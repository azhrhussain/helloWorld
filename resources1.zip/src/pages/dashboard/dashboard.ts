import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';

@IonicPage()
@Component({
  selector: 'page-dashboard',
  templateUrl: 'dashboard.html',
})
export class DashboardPage {

  constructor(
    private afAuth: AngularFireAuth,
    public app: App,
    public navCtrl: NavController, 
    public navParams: NavParams) {
  }
  logout(){

    this.afAuth.auth.signOut()
    
    const root = this.app.getRootNav();
    root.popToRoot();
    //this.navCtrl.push('SigupPage');
  }
  // ionViewDidLoad() {
  //   this.afAuth.authState.subscribe(data => console.log(data));
  //   //console.log('ionViewDidLoad DashboardPage');
  // }

}
