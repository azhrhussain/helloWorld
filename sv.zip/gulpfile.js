﻿
var
    gulp = require('gulp'),
    //images
    newer = require('gulp-newer'),
    imagemin = require('gulp-imagemin'),
    //html
    htmlclean = require('gulp-htmlclean'),

    //html minify
    htmlmin = require('gulp-htmlmin'),
    //js
    concat = require('gulp-concat'),
    deporder = require('gulp-deporder'),
    stripdebug = require('gulp-strip-debug'),
    uglify = require('gulp-uglify'),
    rename = require("gulp-rename");
    sourcemaps = require('gulp-sourcemaps')
    //css
    sass = require('gulp-sass'),
    postcss = require('gulp-postcss'),
    assets = require('postcss-assets'),
    autoprefixer = require('autoprefixer'),
    //autoprefixer = require('gulp-autoprefixer'),
    mqpacker = require('css-mqpacker'),
    cssnano = require('cssnano'),
    concatCss = require('gulp-concat-css'),
    cleanCSS = require('gulp-clean-css'),

    minifyCSS = require('gulp-minify-css'),

    //replace for resources in html file index.html
    htmlreplace = require('gulp-html-replace'),
    //build or 
    devBuild = (process.env.NODE_ENV !== 'production'),
//sequence the tasks
    runSequence = require('run-sequence').use(gulp)

    //folders
    folder = {
        src: 'src/',
        srcjs: 'src/js/',
        srccss: 'src/css/',
        build: 'build/'
    };


// image processing
gulp.task('images', function () {
    var out = folder.build + 'images/';
    return gulp.src(folder.src + 'images/**/*')
      .pipe(newer(out))
      .pipe(imagemin({ optimizationLevel: 8 }))
      .pipe(gulp.dest(out));
});

// HTML processing
gulp.task('html', ['images'], function () {
    var
      out = folder.build,
      page = gulp.src(folder.src + '*.html')
        .pipe(newer(out));

    // minify production code
    if (!devBuild) {
        page = page.pipe(htmlclean());
    }

    return page.pipe(gulp.dest(out));
});

gulp.task('htmlmin', function() {
    return gulp.src(folder.build + '*.html')
      .pipe(htmlmin({collapseWhitespace: true}))
      .pipe(gulp.dest(folder.build));
  });

// JavaScript processing
gulp.task('js', function () {
    var jsBundle = [folder.srcjs + 'slick.js',  folder.srcjs + 'custom.js'];
    var jsbuild = gulp.src(jsBundle)
        .pipe(sourcemaps.init())
        .pipe(deporder())
        .pipe(concat('default.js'))
        .pipe(rename("default.min.js"))
        .pipe(uglify())
        .pipe(sourcemaps.write("/"));

    if (!devBuild) {
           jsbuild = jsbuild
          .pipe(stripdebug())
          .pipe(uglify());
    }

    return jsbuild.pipe(gulp.dest(folder.build + 'js/'));

});

// CSS processing
gulp.task('sass', ['images'], function () {

    var postCssOpts = [
    assets({ loadPaths: ['images/'] }),
    autoprefixer({ browsers: ['last 2 versions', '> 3%'] }),
    mqpacker
    ];

    if (!devBuild) {
        postCssOpts.push(cssnano);
    }

    return gulp.src(folder.src + 'css/style.scss')
      .pipe(sass({
          outputStyle: 'style',
          imagePath: 'images/',
          precision: 3,
          errLogToConsole: true
      }))
      .pipe(postcss(postCssOpts))
      .pipe(gulp.dest(folder.src + 'css/'));

});
//css bundling and minification
gulp.task("css", function () {
   
    // if (!devBuild) {
    //     postCssOpts.push(cssnano);
    // }
    var csBundle = [ folder.srccss + 'third-party/slick.css',  folder.srccss + 'style.css'];
    var cssbuild = gulp.src(csBundle)
    .pipe(sourcemaps.init())
    .pipe(minifyCSS())
    .pipe(rename("style.min.css"))

    return cssbuild.pipe(gulp.dest(folder.build + 'css/'));
});


// Fonts
gulp.task('fonts', function () {
    return gulp.src([
                    folder.src + 'fonts/*'])
            .pipe(gulp.dest(folder.build + 'fonts/'));
});
// Fonts
gulp.task('icon', function () {
    return gulp.src([
                    folder.src + 'favicon.ico'])
            .pipe(gulp.dest(folder.build + '/'));
});


gulp.task('htmlpathReplace', function () {
    var inputHtmlFiles = [folder.src + '/*.html'];

    gulp.src(inputHtmlFiles)
      .pipe(htmlreplace({
          'css': 'css/style.min.css',
          'js': 'js/default.min.js'
      }))
      .pipe(gulp.dest(folder.build ));
});


// build all tasks
gulp.task('build', ['html', 'css', 'icon', 'js', 'htmlpathReplace']);

// watch for changes
gulp.task('watch', function () {
    // css changes
    gulp.watch(folder.src + 'css/**/*.scss', ['sass']);

});

// default task
gulp.task('default', ['build','watch']);

runSequence('default', 'htmlmin');