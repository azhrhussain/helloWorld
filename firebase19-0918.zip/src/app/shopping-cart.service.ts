import { take } from 'rxjs/operators';
import { AngularFireDatabase, snapshotChanges } from 'angularfire2/database';
import { Injectable } from '@angular/core';
import { Product } from './models/product';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartService {

  constructor(private db: AngularFireDatabase) { }

  private create(){
    console.log('shoping service')
   return this.db.list('/shopping-carts').push({
      dateCreated: new Date().getTime()
    });
  }

 private getCart(cartId: string){
   return this.db.object('/shoping-carts/'+ cartId);
 }

  private async getOrCreateCartId(){
    let cartId = localStorage.getItem('cartId');

    if(cartId) return cartId;

    let result = await this.create();
    localStorage.setItem('cartId', result.key);
    return result.key;
   
    // if(!cartId){
      //or
      // this.create().then(result => {
      //   localStorage.setItem('cartId', result.key);

      //   return this.getCart(result.key);
      // });
    // }
    //else
      //return this.getCart(cartId);
    
  }

  async addToCart(product: Product){
    let cartId = await this.getOrCreateCartId();
    let item$ = this.db.list('/shopping-carts/' + cartId + '/items/' + product.key);

    item$.snapshotChanges().subscribe(item => {
      if(item != null) console.log(item + 'old item');
      else 
      console.log(item + "new item");
    });
    // item$.snapshotChanges().subscribe(item=>{
    //   if(item.exists()) item$.update({ quantity: item.quantity + 1});
    //   else item$.set({ product: product, quantity: 1});
    // });
  }


}
