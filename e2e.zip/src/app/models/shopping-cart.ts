import { ShoppingCartItem } from './shopping-cart-item';
import { OnInit } from '@angular/core';
import { Product } from './product';

export class ShoppingCart implements OnInit{
    items: ShoppingCartItem[] = [];
    constructor(public itemsMap:{ [productId:string] : ShoppingCartItem}){
        
        for (let productId in this.itemsMap){
            let item = itemsMap[productId];
            this.items.push(new ShoppingCartItem(item.product, item.quantity));
        }
                
    }
    // getQuantity(){
    //     if(!this.shoppingCart) return 0;
    //     let item = this.shoppingCart.items[this.product.key];
    //     return item ? item.quantity : 0;
    //   }

    getQuantity(product: Product){
        
        let item = this.itemsMap[product.key];
        return item ? item.quantity : 0;
      }

    get totalPrice(){
        let sum=0;
        for(let productId in this.items){
            sum += this.items[productId].totalPrice;
        }
        return sum;
    }

   // constructor(public items: ShoppingCartItem[]){}

    //working ok
    // get productIds(){
    //     return Object.keys(this.items);
    // }
    get totalItemsCount(){
            let count = 0;
            //let mycart=  cart.payload.val();
        for(let productId in this.itemsMap){
            count += this.itemsMap[productId].quantity;
        }
        return count;
    } 

    ngOnInit(){
        
    }
}