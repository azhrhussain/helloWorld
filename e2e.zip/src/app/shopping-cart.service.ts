import { map } from 'rxjs/operators';
import {take }from 'rxjs/operators'; 
import {AngularFireDatabase, snapshotChanges, AngularFireObject }from 'angularfire2/database'; 
import {Injectable }from '@angular/core'; 
import {Product }from './models/product'; 
import { ShoppingCart } from './models/shopping-cart';
import { Observable } from 'rxjs';

@Injectable( {
providedIn:'root'
})
export class ShoppingCartService {
cartId:string; 
constructor(private db:AngularFireDatabase) {}


async getCart() :Promise <Observable<ShoppingCart>>{
  let cartId = await this.getOrCreateCartId();
  return this.db.object<any>('/shopping-carts/' + cartId).snapshotChanges()
  .pipe(map(x => new ShoppingCart(x.payload.val().items))); 
}
async addToCart(product:Product) {
  this.updateItemQuantity(product, 1);
 //working code
 // let cartId = await this.getOrCreateCartId(); 
 // let item$ = this.getItem(cartId, product.key); 

 // item$.snapshotChanges().pipe(take(1)).subscribe((item:any) =>  {
 //   if (item.key != null) {
 //     item$.update( {quantity:( item.payload.node_.children_.root_.value.value_ || 0) + 1}); 
 //   }
 //   else{
 //     item$.set( {product:product, quantity:1}); 
 //   }
 // }); 
//end of working code

               // item$.snapshotChanges().pipe(take(1)).subscribe((item: any) => {
               //    item$.update({ product: product, quantity: ( item.quantity || 0) + 1});
               // });
}

async removeFromCart(product:Product){
 this.updateItemQuantity(product, -1);
}

private create() {
  console.log('shoping service')
  return this.db.list('/shopping-carts').push( {
  dateCreated:new Date().getTime()
  }); 
}
//working befor implement count
// async getCart() :Promise <AngularFireObject<ShoppingCart>>{
//   let cartId = await this.getOrCreateCartId();
//   return this.db.object<any>('/shopping-carts/' + cartId); 
// }

clearCart(){

}

private async getOrCreateCartId(): Promise<string> {
  let cartId = localStorage.getItem('cartId'); 

  if (cartId)return cartId; 

  let result = await this.create(); 
  localStorage.setItem('cartId', result.key); 
  return result.key; 

// if(!cartId){
//or
// this.create().then(result => {
//   localStorage.setItem('cartId', result.key);

//   return this.getCart(result.key);
// });
// }
//else
//return this.getCart(cartId);

}
private getItem(cartId:string, productId:string) {
  return this.db.object < any > ('/shopping-carts/' + cartId + '/items/' + productId); 
}


private async updateItemQuantity(product: Product, change: number){
  let cartId = await this.getOrCreateCartId(); 
  let item$ = this.getItem(cartId, product.key); 

  item$.snapshotChanges().pipe(take(1)).subscribe((item:any) =>  {
    if (item.key != null) {
      item$.update( {quantity:( item.payload.val().quantity || 0) + change}); 
    }
    else{
      item$.set( {product:product, quantity:1}); 
    }
  }); 
}

}
