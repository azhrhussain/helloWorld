import { map } from 'rxjs/operators';
import { AngularFireDatabase } from 'angularfire2/database';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private db: AngularFireDatabase) { }

  create(product){
    return this.db.list('/products').push(product);
  }

  getAll(){
    return this.db.list('/products').snapshotChanges().pipe(map(products=>{
      return products.map(p => {
        const value = p.payload.val();
        const key = p.payload.key;
        return {key, ...value};
      })
    }))
    //return this.db.list('/products').valueChanges();
  }
//get product by id
  get(productId){
    return this.db.object('/products/'+ productId);
  }

  //update product

  update(productId, product){
    return this.db.object('/products/' + productId).update(product);
  }

  //delete product
  delete(productId){
    return this.db.object('/products/' + productId).remove();
  }
}
