﻿
$(document).ready(function () {

    $('#slider').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows: false
      });


    

    var mainslider = {
        slidesToShow: 1,
        slidesToScroll: 1,
        speed: 1000,
        autoplay: true,
        autoplaySpeed: 4000,
        fade: true,
        dots: false,
        focusOnSelect: true,
        asNavFor: '.tab-slider',
        centerMode: false,
        arrows: false,
        autoplay: true,
        infinite: true
    };
    var tabslider = {
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.main-slider',
        arrows: false,
        fade: true,
        infinite: true
    };




    $('.main-slider').on('init', function (e, slick) {
        var $firstAnimatingElements = $('div.item:first-child').find('[data-animation]');
        doAnimations($firstAnimatingElements);
    });
    $('.main-slider').on('beforeChange', function (e, slick, currentSlide, nextSlide) {
        
        var $animatingElements = $('div.item[data-slick-index="' + nextSlide + '"]').find('[data-animation]');
        doAnimations($animatingElements);
        console.log('before change');
        ;
    });
    $('.main-slider').on('afterChange', function(event, slick, currentSlide, nextSlide){
        // finally let's do this after changing slides
        var $animRemoveCurrent = $('div.item[data-slick-index="' + currentSlide + '"]').find("[data-remove]");
        
         removeAnimations($animRemoveCurrent);
        console.log('after change');
    });

    $('.main-slider').slick(mainslider);
    $('.tab-slider').slick(tabslider);

    function doAnimations(elements) {
        var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        elements.each(function () {
            var $this = $(this);
            var $animationDelay = $this.data('delay');
            var $animationType = 'animated ' + $this.data('animation');
            $this.css({
                'animation-delay': $animationDelay,
                '-webkit-animation-delay': $animationDelay
            });
            $this.addClass($animationType).one(animationEndEvents, function () {
                $this.removeClass($animationType);
            });
        });
    }
    function removeAnimations(elements) {
        var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        elements.each(function () {
            var $this = $(this);
            var $animationDelay = $this.data('delay');
            var $animationType = 'animated ' + $this.data('remove');
            $this.css({
                'animation-delay': $animationDelay,
                '-webkit-animation-delay': $animationDelay
            });
            $this.addClass($animationType).one(animationEndEvents, function () {
                $this.removeClass($animationType);
            });
        });
    }




});
