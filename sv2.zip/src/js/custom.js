﻿
$(document).ready(function () {
//slick init
    $('#slider').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows: false,
        autoplay: false
      });

      //counter
$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2500,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});

//fixed nav
var navbar = $('header .navbar');
function navShrink(){
    var scroll= $(window).scrollTop();
    if(scroll>=10){
        navbar.addClass('nav-shrink');
    }
    else {
    navbar.removeClass('nav-shrink'); 
    }
}
navShrink();



$(window).scroll(function(){
    navShrink();
 
});

$('.navbar-brand, a[href$="#"]').on("click",function(event){
    event.preventDefault();
    $('html,body').animate({ scrollTop: 0 }, 'slow');
    });
$('.dropdown-toggle').on("click",function(event){
    event.preventDefault();
    });
//end of onready function
});
