export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyC4vvQl8Ng0fjgTzh9FlBnHLXua_b6RHJE",
    authDomain: "oshop-3200.firebaseapp.com",
    databaseURL: "https://oshop-3200.firebaseio.com",
    projectId: "oshop-3200",
    storageBucket: "",
    messagingSenderId: "599416641183"
  }
};
