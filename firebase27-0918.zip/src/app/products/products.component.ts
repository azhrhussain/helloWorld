import { ShoppingCartService } from './../shopping-cart.service';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from './../product.service';
import { Component, OnInit } from '@angular/core';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: any[] = [];
  filteredProducts: any[] = [];
  //categories$;
  category: string;
  cart:any;
  constructor(private productService: ProductService, route: ActivatedRoute, private shoppingCartService: ShoppingCartService) { 

    

    //switchMap oprators for multiple observables   
    productService.getAll().pipe(switchMap( products =>{
        this.products = products;
        return route.queryParamMap;
      }))
      .subscribe(params =>{
        this.category = params.get('category');
        this.filteredProducts = (this.category) ? this.products.filter(p => p.category === this.category) : this.products;
      });   

  //  or
    // productService.getAll().subscribe( products =>  {
    //   this.products = products;
    //   route.queryParamMap.subscribe(params =>{
    //     this.category = params.get('category');
    //     this.filteredProducts = (this.category) ? this.products.filter(p=>p.category === this.category) : this.products;
       
        // if(this.category){
        //   this.filteredProducts = this.products.filter( filProd => {
        //     return filProd.category == this.category;
        //   });
        // }
        // else {
        //   this.filteredProducts = this.products; 
        // }
        
    //   });
    // });


   
    //this.categories$ = this.categoryService.getAll();
    
  }

  async ngOnInit() {
    let cart$ = await this.shoppingCartService.getCart();
    cart$.subscribe(cart =>{
      this.cart = cart;
    });

    //working befor count
    // let cart$ = await this.shoppingCartService.getCart();
    // cart$.snapshotChanges().subscribe(cart =>{
    //   this.cart = cart.payload.val();
    // });

    // not working (await this.shoppingCartService.getCart()).snapshotChanges().subscribe(cart => {
    //   this.cart = cart;
    // });
  }

}
