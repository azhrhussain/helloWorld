import { ShoppingCartItem } from './shopping-cart-item';
import { OnInit } from '@angular/core';

export class ShoppingCart implements OnInit{
    // items: ShoppingCartItem[];
    // constructor(public itemsMap:{ [productId:string] : ShoppingCartItem}){
    //     for (let productId in this.itemsMap)
    //             this.items.push(this.itemsMap[productId])
    // }


    constructor(public items: ShoppingCartItem[]){}

    //working ok
    get productIds(){
        return Object.keys(this.items);
    }
    get totalItemsCount(){
            let count = 0;
            //let mycart=  cart.payload.val();
        for(let productId in this.items){
            count += this.items[productId].quantity;
        }
        return count;
    } 

    ngOnInit(){
        
    }
}